﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;

namespace COD03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
          
        }
        string Source = "";
        string Destination="";
        CancellationTokenSource TokenSource ;

        //開始執行二個資料庫資料表格內容移轉
            private async void btnStart_Click(object sender, EventArgs e)
            {
                try
                {
                    if (tslblSource .Text .Equals ("***"))
                    {
                        btnSource_Click(null, null);
                        return;
                    }
                    if (tslblDestination.Text.Equals("***"))
                    {
                        btnDestination_Click(null, null);
                        return;
                    }
               
                    string soc = string.Format(/* 連線字串 */, Source);
                    string des = string.Format(/* 連線字串 */, Destination);
                    // TODO:
                    // TokenSource =
                    ExecuteDistributedTransaction(bindingSource1.DataSource as DataTable, soc, des, TokenSource.Token);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        //取消二個資料庫資料移轉作業
            private async void btnCancel_Click(object sender, EventArgs e)
            {
                label1.Text = "0筆";
                if (TokenSource != null)
                {
                    TokenSource.Cancel();
                }
                // TODO:
                //bindingSource1.DataSource =
                //bindingSource2.DataSource = 
            }

        // TODO
        #region  使用非同步方式取得資料庫表格內容
        /*
        async Task<> GetDataAsync(string file)
        {
            DataTable result = new DataTable();

            string connectionstring = string.Format( );
            {

                connection.OpenAsync();
                

            }
            return result;
        }
         */ 
        #endregion

        
        
    //讀取來源資料庫的表格內容
        private async  void btnSource_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                Source = openFileDialog1.FileName;
                tslblSource.Text =Path.GetFileName ( openFileDialog1.FileName);
                // TODO :
                //bindingSource1.DataSource =
                dgvSource.AutoGenerateColumns = true;
            }
        }
        //讀取目的地的資料庫表格內容
        private async void btnDestination_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                Destination = openFileDialog1.FileName;
                tslblDestination.Text = Path.GetFileName(openFileDialog1.FileName);
                //TODO :
                //bindingSource2.DataSource = 
                dgvDestination.AutoGenerateColumns = true;
            }
        }
        //使用CommittableTransaction的方式來確保來源資料或是目的資料庫在交易發生問題或取消作業，把所有交易資料都取消執行。此交易過程將來源資料新增到目的資料成功後將來源資料刪除，所有的指令都透過資料所準備的預儲程序來更新資料
        async Task ExecuteDistributedTransaction(DataTable dt, string connectionString1, string connectionString2, CancellationToken cancellationToken)
        {
            using (SqlConnection connection1 = new SqlConnection(connectionString1))
            using (SqlConnection connection2 = new SqlConnection(connectionString2))
            {
                using (CommittableTransaction transaction = new CommittableTransaction())
                {

                    // TODO
                 

                    try
                    {
                        SqlCommand command1 = connection1.CreateCommand();
                        // TODO

                        SqlCommand command2 = connection2.CreateCommand();
                        // TODO


                        int i = 1;
                        foreach (DataRow rw in dt.Rows)
                        {
                            command1.Parameters.Add(new SqlParameter("@Id", rw["ID"].ToString()));
                            command2.Parameters.Add(new SqlParameter("@Id", rw["ID"]));
                            command2.Parameters.Add(new SqlParameter("@Name", rw["Name"]));
                            command2.Parameters.Add(new SqlParameter("@Message", rw["Message"]));
                            command2.Parameters.Add(new SqlParameter("@PostDate", rw["PostDate"]));
                            command2.Parameters.Add(new SqlParameter("@email", rw["email"]));
                          
                            label1.Text = i.ToString()+"筆";
                          
                            // TODO
                            i += 1;
                            Thread.Sleep(50);
                        }
                        //TODO
                        MessageBox.Show("轉檔成功");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("轉檔失敗");
                        //TODO
                    }
                    finally
                    {
                        connection2.Close();
                        connection1.Close();
                    }
                }
            }
        }
        //完成交易事件更新畫面，顯示目前資料庫表內容
        async void transaction_TransactionCompleted(object sender, TransactionEventArgs e)
        {
            if (e.Transaction.TransactionInformation.Status == TransactionStatus.Committed)
            {
                // TODO:　顯示目前資料庫表內容
                /*
                bindingSource1.DataSource = 
                bindingSource2.DataSource = 
                 */ 
            }
        }

    }
}
