﻿namespace COD04
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPwdCreate = new System.Windows.Forms.TextBox();
            this.cmdCreatePwd = new System.Windows.Forms.Button();
            this.txtPwdToCheck = new System.Windows.Forms.TextBox();
            this.cmdPwdCheck = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPwdHashed = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "密碼：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "密碼檢測：";
            // 
            // txtPwdCreate
            // 
            this.txtPwdCreate.Location = new System.Drawing.Point(123, 28);
            this.txtPwdCreate.MaxLength = 20;
            this.txtPwdCreate.Name = "txtPwdCreate";
            this.txtPwdCreate.PasswordChar = '*';
            this.txtPwdCreate.Size = new System.Drawing.Size(288, 22);
            this.txtPwdCreate.TabIndex = 2;
            // 
            // cmdCreatePwd
            // 
            this.cmdCreatePwd.Location = new System.Drawing.Point(426, 28);
            this.cmdCreatePwd.Name = "cmdCreatePwd";
            this.cmdCreatePwd.Size = new System.Drawing.Size(75, 23);
            this.cmdCreatePwd.TabIndex = 3;
            this.cmdCreatePwd.Text = "密碼加密";
            this.cmdCreatePwd.UseVisualStyleBackColor = true;
            this.cmdCreatePwd.Click += new System.EventHandler(this.cmdCreatePwd_Click);
            // 
            // txtPwdToCheck
            // 
            this.txtPwdToCheck.Location = new System.Drawing.Point(123, 170);
            this.txtPwdToCheck.MaxLength = 20;
            this.txtPwdToCheck.Name = "txtPwdToCheck";
            this.txtPwdToCheck.PasswordChar = '*';
            this.txtPwdToCheck.Size = new System.Drawing.Size(288, 22);
            this.txtPwdToCheck.TabIndex = 4;
            // 
            // cmdPwdCheck
            // 
            this.cmdPwdCheck.Location = new System.Drawing.Point(426, 169);
            this.cmdPwdCheck.Name = "cmdPwdCheck";
            this.cmdPwdCheck.Size = new System.Drawing.Size(75, 23);
            this.cmdPwdCheck.TabIndex = 5;
            this.cmdPwdCheck.Text = "密碼檢測";
            this.cmdPwdCheck.UseVisualStyleBackColor = true;
            this.cmdPwdCheck.Click += new System.EventHandler(this.cmdPwdCheck_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "密碼雜湊：";
            // 
            // txtPwdHashed
            // 
            this.txtPwdHashed.Location = new System.Drawing.Point(123, 70);
            this.txtPwdHashed.Multiline = true;
            this.txtPwdHashed.Name = "txtPwdHashed";
            this.txtPwdHashed.ReadOnly = true;
            this.txtPwdHashed.Size = new System.Drawing.Size(288, 76);
            this.txtPwdHashed.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 237);
            this.Controls.Add(this.txtPwdHashed);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmdPwdCheck);
            this.Controls.Add(this.txtPwdToCheck);
            this.Controls.Add(this.cmdCreatePwd);
            this.Controls.Add(this.txtPwdCreate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "簡單密碼雜湊工具";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPwdCreate;
        private System.Windows.Forms.Button cmdCreatePwd;
        private System.Windows.Forms.TextBox txtPwdToCheck;
        private System.Windows.Forms.Button cmdPwdCheck;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPwdHashed;
    }
}

