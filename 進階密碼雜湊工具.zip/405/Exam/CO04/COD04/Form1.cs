﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COD04
{
    public partial class Form1 : Form
    {
        private byte[] _hashedPwd = null;
        private byte[] _salt = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void cmdCreatePwd_Click(object sender, EventArgs e)
        {
            if (this.txtPwdCreate.Text.Length == 0)
            {
                MessageBox.Show("密碼必須輸入。");
                return;
            }

            this._salt = this.GenerateSalt();
            this._hashedPwd = this.DoPasswordHash(this.txtPwdCreate.Text);
            this.txtPwdSalt.Text = Convert.ToBase64String(this._salt);
            this.txtPwdHashed.Text = Convert.ToBase64String(this._hashedPwd);
            MessageBox.Show("密碼雜湊完成。");
        }

        private void cmdPwdCheck_Click(object sender, EventArgs e)
        {
            if (this.txtPwdToCheck.Text.Length == 0)
            {
                MessageBox.Show("檢測密碼必需輸入。");
                return;
            }
            if (this._hashedPwd == null || this._hashedPwd.Length == 0)
            {
                MessageBox.Show("尚未建立密碼雜湊。");
                return;
            }

            if (VerifyPassword(this.txtPwdToCheck.Text))
                MessageBox.Show("密碼檢測正確。");
            else
                MessageBox.Show("密碼檢測錯誤。");
        }

        private byte[] DoPasswordHash(string Password)
        {
            // TODO 實作密碼雜湊程式，必須使用 RFC 2898 所定義的演算法，否則不予計分。
        }

        private byte[] GenerateSalt()
        {
            // TODO 實作密碼加料的產生程式，加料的值以隨機方式產生。
        }

        private bool VerifyPassword(string PasswordToCheck)
        {
            // TODO 實作密碼比對程式。
        }
    }
}
