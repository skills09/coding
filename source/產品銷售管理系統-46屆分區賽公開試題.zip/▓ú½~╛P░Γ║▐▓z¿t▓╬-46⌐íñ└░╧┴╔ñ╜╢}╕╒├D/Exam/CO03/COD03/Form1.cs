﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COD03
{
    public partial class Form1 : Form
    {

        List<Inventory> list;
        SalesEntities db;

        //初始化SalesEntities 並且把Log寫入到log.txt
        public Form1()
        {
            InitializeComponent();
           
         
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            
            list = db.Inventory.ToList();

            /* TODO 載入Inventory表格到 list 集合後，將產品分類資料加到tscomboBox
            foreach ()
            {
                tscomboBox.Items .Add ();
            }
             */
           
        }

        
        void tscomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // TODO 當下拉選單切換不同資料時取得list集合內容符合所選的產品分類繫結到bindingSource1
        }

       
        //將Base64String轉成正常字串
        private string Decryption(string value)
        {
            string result = "";
            
                try
                {

                    var base64EncodedBytes = System.Convert.FromBase64String("");
                    result = System.Text.Encoding.UTF8.GetString(null);

                }
                catch (System.ArgumentNullException)
                {

                }

            
            return result;
        }

        //執行Saleaberrant預存程序的資料顯示產品及數量
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            var Q ;
            
            if (Q.Count() > 0)
            {
                System.Text.StringBuilder sb = new StringBuilder();
                foreach (var err in Q)
                {
                    sb.AppendLine(string.Format("{0} 數量:{1}" /*TODO */));
                }
                MessageBox.Show(sb.ToString(), "異常清單");
 
            }


         
        }

      
        
        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

            // TODO 將資料庫產品欄位資料轉換正常文字顯示
        }

        
        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // TODO 當儲格資料異動時就回填到資料庫
        }
    }
}
